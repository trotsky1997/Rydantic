use rydantic::{Context,JsonType,Value};
fn decode<T:JsonType>(s:&str)->Option<T>{let mut c=Context::new();T::decode(serde_json::from_str::<Value>(s).unwrap(),&mut c,false)}
#[test]
fn independent_small_range_and_representation_equivalence(){
 for x in -512i32..=512{
  for suffix in ["", ".000", "e+0", "E-0"]{
   let s=format!("{x}{suffix}");
   assert_eq!(decode::<i8>(&s),i8::try_from(x).ok(),"{s}");
   assert_eq!(decode::<u8>(&s),u8::try_from(x).ok(),"{s}");
   assert_eq!(decode::<i128>(&s),Some(i128::from(x)),"{s}");
   assert_eq!(decode::<u128>(&s),u128::try_from(x).ok(),"{s}");
  }
 }
}
#[test]
fn independent_wide_extrema_and_zero(){
 for suffix in ["", ".0", "e0"]{
  let min=format!("{}{suffix}",i128::MIN);let max=format!("{}{suffix}",i128::MAX);let umax=format!("{}{suffix}",u128::MAX);
  assert_eq!(decode::<i128>(&min),Some(i128::MIN));assert_eq!(decode::<u128>(&min),None);
  assert_eq!(decode::<i128>(&max),Some(i128::MAX));assert_eq!(decode::<u128>(&max),Some(i128::MAX as u128));
  assert_eq!(decode::<u128>(&umax),Some(u128::MAX));assert_eq!(decode::<i128>(&umax),None);
 }
 for s in ["-0","-0.0","-0e999999999999999999999999999999","0e-999999999999999999999999999999"]{
  assert_eq!(decode::<u128>(s),Some(0));assert_eq!(decode::<i128>(s),Some(0));
 }
 for s in ["340282366920938463463374607431768211456","-170141183460469231731687303715884105729","1e999999999999999999999999","1e-999999999999999999999999"]{
  assert_eq!(decode::<u128>(s),None);assert_eq!(decode::<i128>(s),None);
 }
}
